Page({

  data: {

    // 默认手机号
    phone: "",

    // 快递列表
    expressList: []

  },


  /**
   * 输入手机号
   */
  onPhoneInput(e) {

    this.setData({

      phone: e.detail.value

    });

  },


  /**
   * 查询快递
   */
  queryExpress() {


    const phone = this.data.phone;


    // 手机号校验
    if (!/^1\d{10}$/.test(phone)) {


      wx.showToast({

        title: "请输入正确的11位手机号",

        icon: "none"

      });


      return;

    }



    wx.request({

      url: "http://127.0.0.1:8080/express/query/" + phone,

      method: "GET",


      success: (res) => {


        if (res.statusCode === 200) {


          let list = res.data;


          // 兼容后端返回格式：
          // {data:[...]}
          if (list.data) {

            list = list.data;

          }


          // 数据格式处理
          list = list.map(item => {


            return {

              // 快递单号
              expressNo: item.expressNo || item.expressNumber || item.number,


              // 8位取件码
              pickupCode: item.pickupCode || item.code,


              // 状态 0待取件 1已出库
              status: item.status


            };


          });



          this.setData({

            expressList: list

          });



        } else {


          wx.showToast({

            title: "查询失败",

            icon: "none"

          });


        }


      },


      fail: () => {


        wx.showToast({

          title: "无法连接服务器",

          icon: "none"

        });


      }


    });


  },


  /**
   * 复制取件码
   */
  copyPickupCode(e) {


    const code = e.currentTarget.dataset.code;



    wx.setClipboardData({

      data: code,


      success: function() {


        wx.showToast({

          title: "取件码已复制",

          icon: "success"

        });


      }


    });


  }


});