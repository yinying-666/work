package com.express.expresssystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpressSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
