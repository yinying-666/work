package com.express.expresssystem.controller;
import com.express.expresssystem.entity.Express;
import com.express.expresssystem.mapper.ExpressMapper;
import com.express.expresssystem.util.TakeCodeUtil;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/express")
public class ExpressController {
    @Resource
    private ExpressMapper expressMapper;

    @PostMapping("/in")
    public Map<String,Object> expressIn(@RequestBody Express express){
        Map<String,Object> result = new HashMap<>();
        String takeCode = TakeCodeUtil.generateTakeCode();
        express.setTakeCode(takeCode);
        int rows = expressMapper.insertExpress(express);
        if(rows > 0){
            result.put("code",200);
            result.put("msg","快递入库成功");
            result.put("takeCode",takeCode);
        }else{
            result.put("code",500);
            result.put("msg","入库失败，请重试");
        }
        return result;
    }

    @GetMapping("/query/{phone}")
    public Map<String,Object> queryByPhone(@PathVariable String phone){
        List<Express> expressList = expressMapper.selectByPhone(phone);
        Map<String,Object> result = new HashMap<>();
        result.put("code",200);
        result.put("data",expressList);
        return result;
    }

    @PutMapping("/out/{takeCode}")
    public Map<String,Object> expressOut(@PathVariable String takeCode){
        Map<String,Object> result = new HashMap<>();
        Express express = expressMapper.selectByTakeCode(takeCode);
        if(express == null){
            result.put("code",500);
            result.put("msg","取件码不存在或该快递已被取出");
            return result;
        }
        expressMapper.updateExpressOut(express);
        result.put("code",200);
        result.put("msg","出库核销完成");
        return result;
    }
}