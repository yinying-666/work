package com.express.expresssystem.entity;
import lombok.Data;
import java.util.Date;
@Data
public class Express {
    private Long id;
    private String phone;
    private String takeCode;
    private String expressNo;
    private Integer status;
    private Date createTime;
    private Date outTime;
}