package com.express.expresssystem.mapper;
import com.express.expresssystem.entity.Express;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import java.util.List;
public interface ExpressMapper {
    @Insert("insert into tb_express(phone,take_code,express_no) values(#{phone},#{takeCode},#{expressNo})")
    int insertExpress(Express express);

    @Select("select * from tb_express where phone = #{phone} order by create_time desc")
    List<Express> selectByPhone(String phone);

    @Select("select * from tb_express where take_code = #{takeCode} and status = 1")
    Express selectByTakeCode(String takeCode);

    @Update("update tb_express set status = 2, out_time = now() where id = #{id}")
    int updateExpressOut(Express express);
}