package com.express.expresssystem.util;
import java.util.Random;
public class TakeCodeUtil {
    private static final String CODE_SOURCE = "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ";
    private static final int CODE_LENGTH = 8;
    public static String generateTakeCode(){
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        for(int i = 0; i < CODE_LENGTH; i++){
            int index = random.nextInt(CODE_SOURCE.length());
            code.append(CODE_SOURCE.charAt(index));
        }
        return code.toString();
    }
}